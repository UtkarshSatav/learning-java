//Write a program to print all alphabets from a to z.

public class Q3{
    public static void main(String[] args){
        for(char i = 'a'; i <= 'z'; i++){
            System.out.println(i);
        }
    }
}