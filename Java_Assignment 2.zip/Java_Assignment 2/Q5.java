//Write a program to print all even numbers between 1 to 50.

public class Q5{
    public static void main(String[] args){
        for(int i = 1; i <= 50; i++){
            if(i % 2 == 0){
                System.out.println(i);
            }
        }
    }
}